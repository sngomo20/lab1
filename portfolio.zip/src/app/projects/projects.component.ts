import { Component } from '@angular/core';


@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss']
})
export class ProjectsComponent {
  projects: Project[] = [
    {
      title: 'Mini Car',
      image: 'path/to/image1.jpg',
      description: 'Project 1 description...',
      role: 'Software Engineer',
      outcome: 'Outcome of Project 1'
    },
    {
      title: 'Pefect Humanoide',
      image: 'path/to/image2.jpg',
      description: 'Project 2 description...',
      role: 'Analyst',
      outcome: 'Outcome of Project 2'
    },
    {
      title: 'Student Application',
      image: 'path/to/image3.jpg',
      description: 'Project 3 description...',
      role: 'Developper',
      outcome: 'Outcome of Project 3'
    }
  ];

}
export interface Project {
  title: string;
  image: string;
  description: string;
  role: string;
  outcome: string;
}
